/**
* Template Name: UpConstruction
* Updated: Jul 27 2023 with Bootstrap v5.3.1
* Template URL: https://bootstrapmade.com/upconstruction-bootstrap-construction-website-template/
* Author: BootstrapMade.com
* License: https://bootstrapmade.com/license/
*/
document.addEventListener('DOMContentLoaded', () => {
  "use strict";

  /**
   * Preloader
   */
  const preloader = document.querySelector('#preloader');
  if (preloader) {
    window.addEventListener('load', () => {
      preloader.remove();
    });
  }

  /**
   * Mobile nav toggle
   */

  const mobileNavShow = document.querySelector('.mobile-nav-show');
  const mobileNavHide = document.querySelector('.mobile-nav-hide');

  document.querySelectorAll('.mobile-nav-toggle').forEach(el => {
    el.addEventListener('click', function(event) {
      event.preventDefault();
      mobileNavToogle();
    })
  });



    // JavaScript code to sort the table rows by cost in descending order
    const sortTableByCost = () => {
        const tableBody = appliancesTable.querySelector("tbody");
        const rows = Array.from(tableBody.querySelectorAll("tr"));
        rows.sort((a, b) => parseFloat(b.cells[4].innerText.slice(4)) - parseFloat(a.cells[4].innerText.slice(4)));
        rows.forEach(row => tableBody.appendChild(row));
      };
   
    const convertToZAR = (usdCost) => {
        const exchangeRate = 15; // Replace this with the latest exchange rate from an API
        return (usdCost * exchangeRate).toFixed(2);
      };
  
      // Function to calculate the cost in ZAR based on the appliance's power usage (in kWh)
      const calculateCostInZAR = (powerUsedUSD) => {
        // Replace these fictional rates with the actual rates from your electricity provider
        const fixedDailyFeeUSD = 0.50;
        const variableRateUSD = 0.12; // Per kWh
  
        // Assuming powerUsedUSD is in kilowatt-hours (kWh)
        const totalCostUSD = fixedDailyFeeUSD + powerUsedUSD * variableRateUSD;
  
        return convertToZAR(totalCostUSD);
      };
      let applianceCount = 4; // Initialize the applianceCount variable
  
  
      // Function to add a new row to the table
      const addTableRow = (applianceName, hoursUsed, powerUsedUSD, status) => {
        const powerUsedZAR = convertToZAR(powerUsedUSD);
        const totalCostZAR = calculateCostInZAR(powerUsedUSD);
  
        const newRow = document.createElement("tr");
        newRow.innerHTML = `
          <td>${applianceCount}</td>
          <td>${applianceName}</td>
          <td>${hoursUsed}</td>
          <td>${powerUsedUSD.toFixed(1)}</td>
          <td>ZAR ${totalCostZAR}</td>
          <td>${status}</td>
          <td>
            <button>Edit</button>
            <button>Delete</button>
          </td>
        `;
        appliancesTable.querySelector("tbody").appendChild(newRow);
        applianceCount++;
      };
  
      // Function to handle form submission when adding a new appliance
      const handleFormSubmit = (event) => {
        event.preventDefault();
        const form = event.target;
        const applianceName = form.applianceName.value;
        const hoursUsed = parseFloat(form.hoursUsed.value);
        const powerUsedUSD = parseFloat(form.powerUsed.value);
        const status = "Active"; // You can set the status dynamically based on your logic
        addTableRow(applianceName, hoursUsed, powerUsedUSD, status);
        form.reset();
        closeModal();
        sortTableByCost();
      };
  
      // Function to create and show the add appliance form
      const showAddApplianceForm = () => {
        const formContainer = document.createElement("div");
        formContainer.innerHTML = `
          <form id="addApplianceForm">
            <label for="applianceName">Appliance Name:</label>
            <input type="text" id="applianceName" required>
            <label for="hoursUsed">Hours of Usage:</label>
            <input type="number" id="hoursUsed" required>
            <label for="powerUsed">Power Used (kWh):</label>
            <input type="number" step="0.1" id="powerUsed" required>
            <button type="submit">Add</button>
            <button type="button" onclick="closeModal()">Cancel</button>
          </form>
        `;
        formContainer.classList.add("modal");
        document.body.appendChild(formContainer);
        const addApplianceForm = document.getElementById("addApplianceForm");
        addApplianceForm.addEventListener("submit", handleFormSubmit);
      };
  
      // Function to close the add appliance form modal
      const closeModal = () => {
        const modal = document.querySelector(".modal");
        if (modal) {
          modal.remove();
        }
      };
  
      const addAppliance = () => {
        showAddApplianceForm();
      const addApplianceForm = document.getElementById("addApplianceForm");
        addApplianceForm.addEventListener("submit", handleFormSubmit);
          sortTableByCost(); // Re-sort the table after adding a new appliance
        };
      // Event listener for the "Add Appliance" button
      const addApplianceBtn = document.getElementById("addApplianceBtn");
      addApplianceBtn.addEventListener("click", addAppliance);
      sortTableByCost();

  function mobileNavToogle() {
    document.querySelector('body').classList.toggle('mobile-nav-active');
    mobileNavShow.classList.toggle('d-none');
    mobileNavHide.classList.toggle('d-none');
  }

  /**
   * Hide mobile nav on same-page/hash links
   */
  document.querySelectorAll('#navbar a').forEach(navbarlink => {

    if (!navbarlink.hash) return;

    let section = document.querySelector(navbarlink.hash);
    if (!section) return;

    navbarlink.addEventListener('click', () => {
      if (document.querySelector('.mobile-nav-active')) {
        mobileNavToogle();
      }
    });

  });

  /**
   * Toggle mobile nav dropdowns
   */
  const navDropdowns = document.querySelectorAll('.navbar .dropdown > a');

  navDropdowns.forEach(el => {
    el.addEventListener('click', function(event) {
      if (document.querySelector('.mobile-nav-active')) {
        event.preventDefault();
        this.classList.toggle('active');
        this.nextElementSibling.classList.toggle('dropdown-active');

        let dropDownIndicator = this.querySelector('.dropdown-indicator');
        dropDownIndicator.classList.toggle('bi-chevron-up');
        dropDownIndicator.classList.toggle('bi-chevron-down');
      }
    })
  });

  /**
   * Scroll top button
   */
  const scrollTop = document.querySelector('.scroll-top');
  if (scrollTop) {
    const togglescrollTop = function() {
      window.scrollY > 100 ? scrollTop.classList.add('active') : scrollTop.classList.remove('active');
    }
    window.addEventListener('load', togglescrollTop);
    document.addEventListener('scroll', togglescrollTop);
    scrollTop.addEventListener('click', window.scrollTo({
      top: 0,
      behavior: 'smooth'
    }));
  }

  /**
   * Initiate glightbox
   */
  const glightbox = GLightbox({
    selector: '.glightbox'
  });

  /**
   * Porfolio isotope and filter
   */
  let portfolionIsotope = document.querySelector('.portfolio-isotope');

  if (portfolionIsotope) {

    let portfolioFilter = portfolionIsotope.getAttribute('data-portfolio-filter') ? portfolionIsotope.getAttribute('data-portfolio-filter') : '*';
    let portfolioLayout = portfolionIsotope.getAttribute('data-portfolio-layout') ? portfolionIsotope.getAttribute('data-portfolio-layout') : 'masonry';
    let portfolioSort = portfolionIsotope.getAttribute('data-portfolio-sort') ? portfolionIsotope.getAttribute('data-portfolio-sort') : 'original-order';

    window.addEventListener('load', () => {
      let portfolioIsotope = new Isotope(document.querySelector('.portfolio-container'), {
        itemSelector: '.portfolio-item',
        layoutMode: portfolioLayout,
        filter: portfolioFilter,
        sortBy: portfolioSort
      });

      let menuFilters = document.querySelectorAll('.portfolio-isotope .portfolio-flters li');
      menuFilters.forEach(function(el) {
        el.addEventListener('click', function() {
          document.querySelector('.portfolio-isotope .portfolio-flters .filter-active').classList.remove('filter-active');
          this.classList.add('filter-active');
          portfolioIsotope.arrange({
            filter: this.getAttribute('data-filter')
          });
          if (typeof aos_init === 'function') {
            aos_init();
          }
        }, false);
      });

    });

  }

  /**
   * Init swiper slider with 1 slide at once in desktop view
   */
  new Swiper('.slides-1', {
    speed: 600,
    loop: true,
    autoplay: {
      delay: 5000,
      disableOnInteraction: false
    },
    slidesPerView: 'auto',
    pagination: {
      el: '.swiper-pagination',
      type: 'bullets',
      clickable: true
    },
    navigation: {
      nextEl: '.swiper-button-next',
      prevEl: '.swiper-button-prev',
    }
  });

  /**
   * Init swiper slider with 2 slides at once in desktop view
   */
  new Swiper('.slides-2', {
    speed: 600,
    loop: true,
    autoplay: {
      delay: 5000,
      disableOnInteraction: false
    },
    slidesPerView: 'auto',
    pagination: {
      el: '.swiper-pagination',
      type: 'bullets',
      clickable: true
    },
    navigation: {
      nextEl: '.swiper-button-next',
      prevEl: '.swiper-button-prev',
    },
    breakpoints: {
      320: {
        slidesPerView: 1,
        spaceBetween: 20
      },

      1200: {
        slidesPerView: 2,
        spaceBetween: 20
      }
    }
  });

  /**
   * Initiate pURE cOUNTER
   */
  new PureCounter();

  /**
   * Animation on scroll function and init
   */
  function aos_init() {
    AOS.init({
      duration: 800,
      easing: 'slide',
      once: true,
      mirror: false
    });
  }
  window.addEventListener('load', () => {
    aos_init();
  });

});